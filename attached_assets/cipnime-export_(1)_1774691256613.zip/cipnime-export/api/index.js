const express = require('express');
const cheerio = require('cheerio');
const cors = require('cors');

const router = express.Router();
router.use(cors());
router.use(express.json());

const JIKAN = 'https://api.jikan.moe/v4';
const ALLANIME_API = 'https://api.allanime.day/api';
const ALLANIME_ORIGIN = 'https://allanime.to';

const BROWSER_UA = 'Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/122.0.0.0 Safari/537.36';

// ===================== JIKAN =====================

async function jikanGet(path) {
  const res = await fetch(`${JIKAN}${path}`, {
    headers: { Accept: 'application/json' },
    signal: AbortSignal.timeout(15000),
  });
  if (!res.ok) throw new Error(`Jikan ${res.status}: ${path}`);
  return res.json();
}

function mapJikanAnime(a) {
  return {
    malId: a.mal_id,
    title: a.title_english || a.title || 'Unknown',
    url: `/anime?malId=${a.mal_id}`,
    thumbnail: a.images?.jpg?.large_image_url || a.images?.jpg?.image_url || '',
    rating: a.score ? String(a.score) : undefined,
    genres: a.genres?.map(g => g.name) || [],
    status: a.status,
    type: a.type,
    episode: a.episodes ? `${a.episodes} eps` : undefined,
  };
}

// ===================== ALLANIME =====================

function decodeAllAnimeUrl(encoded) {
  if (!encoded.startsWith('--')) return encoded;
  const hex = encoded.slice(2);
  try {
    const bytes = Buffer.from(hex, 'hex');
    return bytes.reduce((s, b) => s + String.fromCharCode(b ^ 56), '');
  } catch {
    return '';
  }
}

async function allAnimeSearch(query) {
  const gql = `{ shows(search: { query: "${query.replace(/"/g, '')}", allowAdult: false, allowUnknown: false }, limit: 5, page: 1) { edges { _id name nativeName } } }`;
  const url = `${ALLANIME_API}?` + new URLSearchParams({ query: gql }).toString();
  const res = await fetch(url, {
    headers: { 'User-Agent': BROWSER_UA, Origin: ALLANIME_ORIGIN, Referer: ALLANIME_ORIGIN + '/', Accept: 'application/json' },
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) throw new Error(`AllAnime search ${res.status}`);
  const data = await res.json();
  return data?.data?.shows?.edges || [];
}

async function allAnimeGetEpisode(showId, episode, translationType = 'sub') {
  const gql = `{ episode(showId: "${showId}", translationType: ${translationType}, episodeString: "${episode}") { episodeString sourceUrls } }`;
  const url = `${ALLANIME_API}?` + new URLSearchParams({ query: gql }).toString();
  const res = await fetch(url, {
    headers: { 'User-Agent': BROWSER_UA, Origin: ALLANIME_ORIGIN, Referer: ALLANIME_ORIGIN + '/', Accept: 'application/json' },
    signal: AbortSignal.timeout(12000),
  });
  if (!res.ok) throw new Error(`AllAnime episode ${res.status}`);
  const data = await res.json();
  return data?.data?.episode?.sourceUrls || [];
}

const SERVER_NAME_MAP = {
  'Yt-mp4': 'AllAnime HD', 'Default': 'AllAnime', 'S-mp4': 'AllAnime S',
  'Luf-Mp4': 'AllAnime L', 'Uv-mp4': 'AllAnime UV', 'Ok': 'OK.ru',
  'Vid-mp4': 'GogoPlay', 'Ss-Hls': 'StreamSB', 'Mp4': 'MP4Upload', 'Sl-mp4': 'Streamlare',
};

function processAllAnimeSources(rawSources) {
  const iframeSources = [];
  const directSources = [];
  const sorted = [...rawSources].sort((a, b) => b.priority - a.priority);

  for (const src of sorted) {
    let url = src.sourceUrl;
    if (url.startsWith('--')) {
      const decoded = decodeAllAnimeUrl(url);
      if (!decoded || !decoded.startsWith('http')) continue;
      url = decoded;
    }
    if (!url.startsWith('http')) continue;
    if (url.includes('/apivtwo/clock')) continue;

    const server = SERVER_NAME_MAP[src.sourceName] || src.sourceName;

    if (src.type === 'iframe') {
      iframeSources.push({ server, url, type: 'iframe' });
    } else if (url.includes('.m3u8')) {
      directSources.push({ server: server + ' (HLS)', url, isExternal: true, type: 'external' });
    } else if (url.includes('fast4speed') || url.includes('allanime')) {
      directSources.push({ server: server + ' (Unduh)', url, isExternal: true, type: 'external' });
    } else {
      iframeSources.push({ server, url, type: 'iframe' });
    }
  }
  return [...iframeSources, ...directSources];
}

// ===================== KUSONIME (fallback) =====================

async function fetchHtml(url, referer) {
  const headers = { 'User-Agent': BROWSER_UA, Accept: 'text/html' };
  if (referer) headers['Referer'] = referer;
  const res = await fetch(url, { headers, signal: AbortSignal.timeout(12000), redirect: 'follow' });
  if (!res.ok) throw new Error(`HTTP ${res.status}: ${url}`);
  return res.text();
}

async function kusonimeSearch(query) {
  try {
    const html = await fetchHtml(`https://kusonime.com/?s=${encodeURIComponent(query)}`, 'https://kusonime.com/');
    const $ = cheerio.load(html);
    const results = [];
    $('div.col.ani').each((_, el) => {
      const title = $(el).find('h2').text().trim();
      const href = $(el).find('a').first().attr('href') || '';
      if (title && href) results.push({ title, url: href });
    });
    return results;
  } catch { return []; }
}

async function kusonimeGetStreams(episodeUrl) {
  try {
    const html = await fetchHtml(episodeUrl, 'https://kusonime.com/');
    const $ = cheerio.load(html);
    const sources = [];
    $('a[data-content]').each((_, el) => {
      const server = $(el).text().trim();
      const content = $(el).attr('data-content') || '';
      const match = content.match(/src=['"]([^'"]+)['"]/);
      if (match) sources.push({ server, url: match[1], type: 'iframe' });
    });
    $('iframe').each((_, el) => {
      const src = $(el).attr('src') || '';
      if (src && src !== 'about:blank' && !sources.find(s => s.url === src)) {
        sources.push({ server: 'Kusonime Player', url: src.startsWith('//') ? 'https:' + src : src, type: 'iframe' });
      }
    });
    return sources;
  } catch { return []; }
}

// ===================== API ROUTES =====================

router.get('/anime/latest', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const data = await jikanGet(`/anime?status=airing&order_by=score&sort=desc&page=${page}&limit=24&sfw=true`);
    res.json({ items: (data.data || []).map(mapJikanAnime), hasNextPage: data.pagination?.has_next_page ?? false, currentPage: page });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/anime/ongoing', async (req, res) => {
  try {
    const page = parseInt(req.query.page) || 1;
    const data = await jikanGet(`/seasons/now?page=${page}&limit=24`);
    res.json({ items: (data.data || []).map(mapJikanAnime), hasNextPage: data.pagination?.has_next_page ?? false, currentPage: page });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/anime/search', async (req, res) => {
  try {
    const q = req.query.q || '';
    const page = parseInt(req.query.page) || 1;
    const data = await jikanGet(`/anime?q=${encodeURIComponent(q)}&page=${page}&limit=24&sfw=true`);
    res.json({ items: (data.data || []).map(mapJikanAnime), hasNextPage: data.pagination?.has_next_page ?? false, currentPage: page });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/anime/detail', async (req, res) => {
  try {
    const url = req.query.url || '';
    const malIdMatch = url.match(/malId=(\d+)/);
    if (!malIdMatch) return res.status(400).json({ error: 'malId required' });
    const malId = parseInt(malIdMatch[1]);

    const [detailData, epData] = await Promise.allSettled([
      jikanGet(`/anime/${malId}/full`),
      jikanGet(`/anime/${malId}/episodes?page=1`),
    ]);

    const a = detailData.status === 'fulfilled' ? detailData.value.data : {};
    const epList = epData.status === 'fulfilled' ? (epData.value.data || []) : [];
    const totalEpisodes = a.episodes || 0;

    let episodes = [];
    if (epList.length > 0) {
      episodes = epList.map(ep => ({
        episode: `Episode ${ep.mal_id}${ep.title && ep.title !== 'N/A' ? ` - ${ep.title}` : ''}`,
        url: `/watch?malId=${malId}&ep=${ep.mal_id}`,
        id: String(ep.mal_id),
      }));
    } else if (totalEpisodes > 0) {
      episodes = Array.from({ length: Math.min(totalEpisodes, 200) }, (_, i) => ({
        episode: `Episode ${i + 1}`,
        url: `/watch?malId=${malId}&ep=${i + 1}`,
        id: String(i + 1),
      }));
    } else {
      episodes = [{ episode: 'Episode 1', url: `/watch?malId=${malId}&ep=1`, id: '1' }];
    }

    res.json({
      malId,
      title: a.title_english || a.title || 'Unknown',
      url,
      thumbnail: a.images?.jpg?.large_image_url || '',
      synopsis: a.synopsis || '',
      rating: a.score ? String(a.score) : '',
      status: a.status || '',
      type: a.type || '',
      genres: (a.genres || []).map(g => g.name),
      episodes,
      totalEpisodes: episodes.length || totalEpisodes,
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/anime/episode', async (req, res) => {
  try {
    const url = req.query.url || '';
    const malIdMatch = url.match(/malId=(\d+)/);
    const epMatch = url.match(/ep=(\d+)/);
    const malId = malIdMatch ? malIdMatch[1] : null;
    const ep = epMatch ? epMatch[1] : '1';

    let animeTitle = 'Anime';
    let animeEnTitle = '';
    if (malId) {
      try {
        const data = await jikanGet(`/anime/${malId}`);
        animeTitle = data.data?.title || 'Anime';
        animeEnTitle = data.data?.title_english || data.data?.title || 'Anime';
      } catch (_) {}
    }

    const sources = [];
    const searchTitle = animeEnTitle || animeTitle;

    // Strategy 1: AllAnime API
    try {
      const shows = await allAnimeSearch(searchTitle);
      if (shows.length > 0) {
        const showId = shows[0]._id;
        let rawSources = await allAnimeGetEpisode(showId, ep, 'sub');
        if (rawSources.length === 0) rawSources = await allAnimeGetEpisode(showId, ep, 'dub');
        sources.push(...processAllAnimeSources(rawSources));
      }
    } catch (_) {}

    // Strategy 2: Kusonime (Indonesian sub)
    if (sources.length < 2) {
      try {
        const kusoResults = await kusonimeSearch(animeTitle);
        if (kusoResults.length > 0) {
          const epPageUrl = kusoResults[0].url.replace(/\/$/, '') + `-episode-${ep}/`;
          const kusoSources = await kusonimeGetStreams(epPageUrl);
          for (const src of kusoSources) {
            if (!sources.find(s => s.url === src.url)) {
              sources.push({ ...src, server: `Kusonime - ${src.server}` });
            }
          }
        }
      } catch (_) {}
    }

    // Strategy 3: External fallback
    if (sources.length === 0) {
      sources.push(
        { server: 'Gogoanime', url: `https://anitaku.pe/search.html?keyword=${encodeURIComponent(searchTitle)}`, isExternal: true, type: 'external' },
        { server: 'Kusonime', url: `https://kusonime.com/?s=${encodeURIComponent(animeTitle)}`, isExternal: true, type: 'external' },
        { server: 'Samehadaku', url: `https://samehadaku.link/?s=${encodeURIComponent(animeTitle)}`, isExternal: true, type: 'external' }
      );
    }

    res.json({
      title: animeEnTitle || animeTitle,
      episode: `Episode ${ep}`,
      sources,
      downloadLinks: [
        { server: 'Kusonime', url: `https://kusonime.com/?s=${encodeURIComponent(animeTitle)}` },
        { server: 'Samehadaku', url: `https://samehadaku.link/?s=${encodeURIComponent(animeTitle)}` },
        { server: 'Animeindo', url: `https://animeindo.cfd/?s=${encodeURIComponent(animeTitle)}` },
      ],
    });
  } catch (e) { res.status(500).json({ error: e.message }); }
});

router.get('/healthz', (req, res) => res.json({ status: 'ok' }));

module.exports = router;
