import { useQuery } from "@tanstack/react-query";
import { apiGet } from "@/lib/utils";

export interface AnimeItem {
  malId: number;
  title: string;
  url: string;
  thumbnail: string;
  rating?: string;
  genres?: string[];
  status?: string;
  type?: string;
  episode?: string;
}

export interface AnimeListResponse {
  items: AnimeItem[];
  hasNextPage: boolean;
  currentPage: number;
}

export interface EpisodeItem {
  episode: string;
  url: string;
  id: string;
}

export interface AnimeDetailResponse {
  malId: number;
  title: string;
  url: string;
  thumbnail: string;
  synopsis?: string;
  rating?: string;
  status?: string;
  type?: string;
  genres?: string[];
  episodes: EpisodeItem[];
  totalEpisodes: number;
}

export interface StreamSource {
  server: string;
  url: string;
  quality?: string;
  isExternal?: boolean;
}

export interface EpisodeResponse {
  title: string;
  episode: string;
  sources: StreamSource[];
  downloadLinks?: Array<{ server: string; url: string }>;
}

export function useLatestAnime(page = 1) {
  return useQuery<AnimeListResponse>({
    queryKey: ["latest-anime", page],
    queryFn: () => apiGet<AnimeListResponse>("/anime/latest", { page: String(page) }),
  });
}

export function useOngoingAnime(page = 1) {
  return useQuery<AnimeListResponse>({
    queryKey: ["ongoing-anime", page],
    queryFn: () => apiGet<AnimeListResponse>("/anime/ongoing", { page: String(page) }),
  });
}

export function useSearchAnime(query: string, page = 1) {
  return useQuery<AnimeListResponse>({
    queryKey: ["search-anime", query, page],
    queryFn: () => apiGet<AnimeListResponse>("/anime/search", { q: query, page: String(page) }),
    enabled: query.length > 1,
  });
}

export function useAnimeDetail(url: string) {
  return useQuery<AnimeDetailResponse>({
    queryKey: ["anime-detail", url],
    queryFn: () => apiGet<AnimeDetailResponse>("/anime/detail", { url }),
    enabled: !!url,
  });
}

export function useEpisodeSources(url: string) {
  return useQuery<EpisodeResponse>({
    queryKey: ["episode-sources", url],
    queryFn: () => apiGet<EpisodeResponse>("/anime/episode", { url }),
    enabled: !!url,
  });
}
