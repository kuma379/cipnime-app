import { useState } from "react";
import { useLocation } from "wouter";
import { Star, Play } from "lucide-react";
import { motion } from "framer-motion";
import { type AnimeItem } from "@/hooks/useApi";

interface AnimeCardProps {
  anime: AnimeItem;
  index?: number;
}

export default function AnimeCard({ anime, index = 0 }: AnimeCardProps) {
  const [, navigate] = useLocation();
  const [imgError, setImgError] = useState(false);

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      animate={{ opacity: 1, y: 0 }}
      transition={{ duration: 0.3, delay: Math.min(index * 0.04, 0.4) }}
      className="group cursor-pointer"
      onClick={() => navigate(anime.url)}
    >
      <div className="relative aspect-[2/3] rounded-xl overflow-hidden bg-secondary border border-border group-hover:border-primary/50 transition-all duration-300 shadow-lg group-hover:shadow-primary/20 group-hover:shadow-xl">
        {/* Thumbnail */}
        {!imgError && anime.thumbnail ? (
          <img
            src={anime.thumbnail}
            alt={anime.title}
            loading="lazy"
            onError={() => setImgError(true)}
            className="w-full h-full object-cover group-hover:scale-105 transition-transform duration-500"
          />
        ) : (
          <div className="w-full h-full bg-gradient-to-br from-primary/20 to-secondary flex items-center justify-center">
            <Play className="w-12 h-12 text-primary/40" />
          </div>
        )}

        {/* Overlay on hover */}
        <div className="absolute inset-0 bg-gradient-to-t from-black/80 via-black/20 to-transparent opacity-0 group-hover:opacity-100 transition-opacity duration-300 flex flex-col justify-end p-3">
          <motion.div
            initial={{ scale: 0 }}
            whileHover={{ scale: 1 }}
            className="absolute inset-0 flex items-center justify-center"
          >
            <div className="w-14 h-14 rounded-full bg-primary/90 flex items-center justify-center shadow-lg">
              <Play className="w-6 h-6 text-white ml-0.5" fill="white" />
            </div>
          </motion.div>
        </div>

        {/* Rating badge */}
        {anime.rating && (
          <div className="absolute top-2 left-2 flex items-center gap-1 px-2 py-0.5 rounded-full bg-black/70 backdrop-blur-sm text-xs font-semibold text-yellow-400">
            <Star className="w-3 h-3 fill-yellow-400" />
            {anime.rating}
          </div>
        )}

        {/* Type badge */}
        {anime.type && (
          <div className="absolute top-2 right-2 px-2 py-0.5 rounded-full bg-primary/80 backdrop-blur-sm text-xs font-bold text-white">
            {anime.type}
          </div>
        )}
      </div>

      {/* Info */}
      <div className="mt-2 px-0.5">
        <h3 className="text-sm font-semibold text-foreground line-clamp-2 group-hover:text-primary transition-colors leading-tight">
          {anime.title}
        </h3>
        {anime.genres && anime.genres.length > 0 && (
          <p className="text-xs text-muted-foreground mt-0.5 truncate">
            {anime.genres.slice(0, 2).join(" • ")}
          </p>
        )}
      </div>
    </motion.div>
  );
}
