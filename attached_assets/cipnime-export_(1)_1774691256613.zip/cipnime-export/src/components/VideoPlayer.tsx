import { useState, useRef } from "react";
import { Play, ExternalLink, AlertCircle, Maximize2, Tv } from "lucide-react";
import { motion } from "framer-motion";
import { type StreamSource } from "@/hooks/useApi";

interface VideoPlayerProps {
  sources: StreamSource[];
  title: string;
  episode: string;
}

export default function VideoPlayer({ sources, title, episode }: VideoPlayerProps) {
  const [selectedIdx, setSelectedIdx] = useState(0);
  const containerRef = useRef<HTMLDivElement>(null);

  const current = sources[selectedIdx];
  const sourceType = (current as { type?: string })?.type;
  const isExternal = current?.isExternal || sourceType === "external";
  const isDirect = sourceType === "direct" || sourceType === "hls";

  async function toggleFullscreen() {
    if (!document.fullscreenElement && containerRef.current) {
      await containerRef.current.requestFullscreen();
    } else {
      await document.exitFullscreen();
    }
  }

  if (!sources || sources.length === 0) {
    return (
      <div className="aspect-video bg-black/80 rounded-xl flex flex-col items-center justify-center gap-4 border border-border">
        <AlertCircle className="w-12 h-12 text-muted-foreground" />
        <p className="text-muted-foreground text-sm">Stream tidak tersedia saat ini</p>
        <p className="text-muted-foreground text-xs">Coba cari di situs streaming langsung</p>
      </div>
    );
  }

  return (
    <div className="flex flex-col gap-3">
      {/* Player */}
      <div ref={containerRef} className="relative bg-black rounded-xl overflow-hidden border border-border group">
        <div className="aspect-video">
          {isExternal ? (
            <div className="w-full h-full flex flex-col items-center justify-center gap-5 bg-gradient-to-br from-gray-900 to-black p-8">
              <div className="w-16 h-16 rounded-full bg-primary/20 flex items-center justify-center">
                <ExternalLink className="w-8 h-8 text-primary" />
              </div>
              <div className="text-center max-w-sm">
                <p className="text-foreground font-semibold text-lg mb-1">{title}</p>
                <p className="text-muted-foreground text-sm mb-4">{episode}</p>
                <p className="text-muted-foreground text-xs mb-6">
                  Stream dari server <strong className="text-foreground">{current.server}</strong> tersedia di situs eksternal.
                </p>
                <a
                  href={current.url}
                  target="_blank"
                  rel="noopener noreferrer"
                  className="inline-flex items-center gap-2 px-6 py-3 bg-primary text-white rounded-lg font-semibold hover:bg-primary/90 transition-colors"
                >
                  <Play className="w-4 h-4" fill="white" />
                  Tonton di {current.server}
                  <ExternalLink className="w-3 h-3" />
                </a>
              </div>
            </div>
          ) : isDirect ? (
            <video
              key={current.url}
              src={current.url}
              controls
              autoPlay
              className="w-full h-full"
              crossOrigin="anonymous"
              style={{ background: "black" }}
            >
              <source src={current.url} />
              Browser Anda tidak mendukung video HTML5.
            </video>
          ) : (
            <>
              <iframe
                key={current.url}
                src={current.url}
                className="w-full h-full"
                allowFullScreen
                allow="fullscreen; autoplay; encrypted-media; picture-in-picture"
                frameBorder="0"
                scrolling="no"
                referrerPolicy="no-referrer"
                title={`${title} ${episode}`}
              />
              <button
                onClick={toggleFullscreen}
                className="absolute bottom-3 right-3 p-2 bg-black/50 rounded-lg text-white opacity-0 group-hover:opacity-100 transition-opacity hover:bg-black/80"
              >
                <Maximize2 className="w-4 h-4" />
              </button>
            </>
          )}
        </div>
      </div>

      {/* Server selector */}
      {sources.length > 1 && (
        <div className="flex flex-col gap-2">
          <p className="text-xs font-medium text-muted-foreground uppercase tracking-wider">Pilih Server</p>
          <div className="flex flex-wrap gap-2">
            {sources.map((src, i) => {
              const ext = src.isExternal || (src as { type?: string }).type === "external";
              const direct = (src as { type?: string }).type === "direct" || (src as { type?: string }).type === "hls";
              return (
                <motion.button
                  key={`${src.server}-${i}`}
                  whileHover={{ scale: 1.03 }}
                  whileTap={{ scale: 0.97 }}
                  onClick={() => setSelectedIdx(i)}
                  className={`px-3 py-1.5 rounded-lg text-sm font-medium transition-all border flex items-center gap-1.5 ${
                    i === selectedIdx
                      ? "bg-primary text-white border-primary"
                      : "bg-secondary text-muted-foreground border-border hover:border-primary/40 hover:text-foreground"
                  }`}
                >
                  {direct && <Tv className="w-3 h-3 opacity-70" />}
                  {src.server}
                  {src.quality && <span className="text-xs opacity-70">({src.quality})</span>}
                  {ext && <ExternalLink className="w-3 h-3 opacity-60" />}
                </motion.button>
              );
            })}
          </div>
        </div>
      )}
    </div>
  );
}
