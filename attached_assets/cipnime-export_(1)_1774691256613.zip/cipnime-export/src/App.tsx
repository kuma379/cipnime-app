import { Switch, Route } from "wouter";
import { QueryClient, QueryClientProvider } from "@tanstack/react-query";
import Home from "@/pages/Home";
import Search from "@/pages/Search";
import AnimeDetail from "@/pages/AnimeDetail";
import Watch from "@/pages/Watch";

const queryClient = new QueryClient({
  defaultOptions: {
    queries: {
      refetchOnWindowFocus: false,
      staleTime: 1000 * 60 * 5,
      retry: 1,
    },
  },
});

export default function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <Switch>
        <Route path="/" component={Home} />
        <Route path="/search" component={Search} />
        <Route path="/anime" component={AnimeDetail} />
        <Route path="/watch" component={Watch} />
        <Route>
          <div className="min-h-screen flex items-center justify-center bg-background">
            <div className="text-center">
              <h1 className="text-6xl font-bold text-primary mb-4">404</h1>
              <p className="text-muted-foreground mb-6">Halaman tidak ditemukan</p>
              <a href="/" className="px-6 py-2 bg-primary text-white rounded-lg hover:bg-primary/90 transition-colors">Kembali ke Beranda</a>
            </div>
          </div>
        </Route>
      </Switch>
    </QueryClientProvider>
  );
}
