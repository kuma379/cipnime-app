import { useState } from "react";
import { useLocation } from "wouter";
import { ChevronLeft, ChevronRight, List, Loader2, ExternalLink } from "lucide-react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import VideoPlayer from "@/components/VideoPlayer";
import { useEpisodeSources, useAnimeDetail } from "@/hooks/useApi";

export default function Watch() {
  const [, navigate] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const malId = params.get("malId") || "";
  const ep = parseInt(params.get("ep") || "1");
  const watchUrl = `/watch?malId=${malId}&ep=${ep}`;
  const animeUrl = `/anime?malId=${malId}`;

  const [showEpList, setShowEpList] = useState(false);

  const { data: episodeData, isLoading } = useEpisodeSources(watchUrl);
  const { data: animeData } = useAnimeDetail(animeUrl);

  const episodes = animeData?.episodes || [];
  const totalEps = episodes.length;
  const currentEpIndex = episodes.findIndex(e => e.url === watchUrl || e.id === String(ep));

  function goToEp(n: number) {
    navigate(`/watch?malId=${malId}&ep=${n}`);
    setShowEpList(false);
    window.scrollTo({ top: 0, behavior: "smooth" });
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-6 max-w-5xl">
        {/* Breadcrumb */}
        <div className="flex items-center gap-2 text-sm text-muted-foreground mb-4 flex-wrap">
          <button onClick={() => navigate("/")} className="hover:text-foreground transition-colors">Beranda</button>
          <span>/</span>
          {animeData ? (
            <button onClick={() => navigate(animeUrl)} className="hover:text-foreground transition-colors line-clamp-1 max-w-[200px]">
              {animeData.title}
            </button>
          ) : (
            <span>Anime</span>
          )}
          <span>/</span>
          <span className="text-foreground font-medium">Episode {ep}</span>
        </div>

        <div className="flex flex-col lg:flex-row gap-6">
          {/* Main player area */}
          <div className="flex-1 min-w-0">
            {/* Title */}
            <div className="mb-4">
              <h1 className="text-xl md:text-2xl font-bold font-display leading-tight">
                {episodeData?.title || animeData?.title || "Memuat..."}
              </h1>
              <p className="text-muted-foreground text-sm mt-1">Episode {ep}</p>
            </div>

            {/* Player */}
            {isLoading ? (
              <div className="aspect-video bg-black/80 rounded-xl flex items-center justify-center border border-border">
                <div className="text-center">
                  <Loader2 className="w-10 h-10 text-primary animate-spin mx-auto mb-3" />
                  <p className="text-sm text-muted-foreground">Mencari stream...</p>
                  <p className="text-xs text-muted-foreground/60 mt-1">Mohon tunggu, proses ini bisa memakan waktu</p>
                </div>
              </div>
            ) : (
              <VideoPlayer
                sources={episodeData?.sources || []}
                title={episodeData?.title || ""}
                episode={episodeData?.episode || `Episode ${ep}`}
              />
            )}

            {/* Navigation */}
            <div className="flex items-center justify-between mt-4 gap-3">
              <button
                onClick={() => ep > 1 && goToEp(ep - 1)}
                disabled={ep <= 1}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary border border-border text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/10 hover:border-primary/40 transition-colors"
              >
                <ChevronLeft className="w-4 h-4" /> Episode Sebelumnya
              </button>

              <button
                onClick={() => setShowEpList(v => !v)}
                className={`flex items-center gap-2 px-4 py-2.5 rounded-xl border text-sm font-medium transition-colors ${showEpList ? "bg-primary text-white border-primary" : "bg-secondary border-border hover:bg-primary/10 hover:border-primary/40"}`}
              >
                <List className="w-4 h-4" /> Daftar Ep
              </button>

              <button
                onClick={() => goToEp(ep + 1)}
                disabled={totalEps > 0 && ep >= totalEps}
                className="flex items-center gap-2 px-4 py-2.5 rounded-xl bg-secondary border border-border text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/10 hover:border-primary/40 transition-colors"
              >
                Episode Berikutnya <ChevronRight className="w-4 h-4" />
              </button>
            </div>

            {/* Download links */}
            {episodeData?.downloadLinks && episodeData.downloadLinks.length > 0 && (
              <div className="mt-6 p-4 rounded-xl bg-secondary border border-border">
                <h3 className="text-sm font-semibold mb-3 text-muted-foreground uppercase tracking-wider">Link Download / Streaming Alternatif</h3>
                <div className="flex flex-wrap gap-2">
                  {episodeData.downloadLinks.map(link => (
                    <a
                      key={link.server}
                      href={link.url}
                      target="_blank"
                      rel="noopener noreferrer"
                      className="flex items-center gap-1.5 px-3 py-1.5 rounded-lg bg-background border border-border text-sm text-muted-foreground hover:text-foreground hover:border-primary/40 transition-colors"
                    >
                      <ExternalLink className="w-3 h-3" /> {link.server}
                    </a>
                  ))}
                </div>
              </div>
            )}
          </div>

          {/* Episode sidebar */}
          <div className={`lg:w-64 ${showEpList ? "block" : "hidden lg:block"}`}>
            <div className="sticky top-20">
              <h3 className="text-sm font-bold font-display mb-3 text-muted-foreground uppercase tracking-wider">
                Daftar Episode
                {totalEps > 0 && <span className="ml-2 text-primary">({totalEps})</span>}
              </h3>
              <div className="max-h-[600px] overflow-y-auto rounded-xl bg-secondary border border-border p-1 flex flex-col gap-1">
                {animeData ? episodes.map((epItem) => {
                  const epNum = parseInt(epItem.id);
                  const isActive = epNum === ep;
                  return (
                    <button
                      key={epItem.id}
                      onClick={() => goToEp(epNum)}
                      className={`w-full text-left px-3 py-2 rounded-lg text-sm transition-colors ${
                        isActive ? "bg-primary text-white font-semibold" : "text-muted-foreground hover:bg-background hover:text-foreground"
                      }`}
                    >
                      {epItem.episode}
                    </button>
                  );
                }) : (
                  <div className="py-4 text-center text-xs text-muted-foreground">Memuat daftar episode...</div>
                )}
              </div>
            </div>
          </div>
        </div>
      </main>
    </div>
  );
}
