import { useLocation } from "wouter";
import { Star, Play, Tv, Tag, Info, ChevronLeft, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import { useAnimeDetail } from "@/hooks/useApi";

export default function AnimeDetail() {
  const [, navigate] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const malId = params.get("malId") || "";
  const animeUrl = `/anime?malId=${malId}`;

  const { data, isLoading, isError } = useAnimeDetail(animeUrl);

  if (!malId) {
    return (
      <div className="min-h-screen bg-background flex items-center justify-center">
        <p className="text-muted-foreground">ID anime tidak valid</p>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />
      <main className="container mx-auto px-4 py-10 max-w-5xl">
        <button onClick={() => navigate("/")} className="flex items-center gap-2 text-sm text-muted-foreground hover:text-foreground mb-6 transition-colors">
          <ChevronLeft className="w-4 h-4" /> Kembali
        </button>

        {isLoading && (
          <div className="flex items-center justify-center py-32">
            <Loader2 className="w-8 h-8 text-primary animate-spin" />
          </div>
        )}

        {isError && (
          <div className="text-center py-32">
            <p className="text-muted-foreground">Gagal memuat detail anime</p>
          </div>
        )}

        {data && (
          <motion.div initial={{ opacity: 0, y: 20 }} animate={{ opacity: 1, y: 0 }}>
            {/* Header */}
            <div className="flex flex-col md:flex-row gap-8 mb-10">
              {/* Poster */}
              <div className="w-full md:w-56 shrink-0">
                <div className="aspect-[2/3] rounded-2xl overflow-hidden bg-secondary border border-border shadow-xl shadow-black/20">
                  {data.thumbnail ? (
                    <img src={data.thumbnail} alt={data.title} className="w-full h-full object-cover" />
                  ) : (
                    <div className="w-full h-full flex items-center justify-center">
                      <Tv className="w-16 h-16 text-muted-foreground/30" />
                    </div>
                  )}
                </div>
              </div>

              {/* Info */}
              <div className="flex-1 flex flex-col justify-center">
                <h1 className="text-3xl md:text-4xl font-black font-display mb-3 leading-tight">{data.title}</h1>

                {/* Badges */}
                <div className="flex flex-wrap gap-2 mb-4">
                  {data.rating && (
                    <span className="flex items-center gap-1 px-3 py-1 rounded-full bg-yellow-500/10 text-yellow-400 border border-yellow-500/20 text-sm font-medium">
                      <Star className="w-3 h-3 fill-yellow-400" /> {data.rating}
                    </span>
                  )}
                  {data.status && (
                    <span className="px-3 py-1 rounded-full bg-primary/10 text-primary border border-primary/20 text-sm font-medium">
                      {data.status}
                    </span>
                  )}
                  {data.type && (
                    <span className="px-3 py-1 rounded-full bg-secondary text-muted-foreground border border-border text-sm font-medium">
                      {data.type}
                    </span>
                  )}
                </div>

                {/* Genres */}
                {data.genres && data.genres.length > 0 && (
                  <div className="flex items-center gap-2 flex-wrap mb-4">
                    <Tag className="w-4 h-4 text-muted-foreground" />
                    {data.genres.map(g => (
                      <span key={g} className="px-2.5 py-0.5 rounded-md bg-secondary text-xs font-medium text-muted-foreground border border-border">
                        {g}
                      </span>
                    ))}
                  </div>
                )}

                {/* Synopsis */}
                {data.synopsis && (
                  <div className="mt-2">
                    <div className="flex items-center gap-2 mb-2">
                      <Info className="w-4 h-4 text-muted-foreground" />
                      <span className="text-sm font-medium text-muted-foreground">Sinopsis</span>
                    </div>
                    <p className="text-sm text-foreground/80 leading-relaxed line-clamp-3 md:line-clamp-5">
                      {data.synopsis}
                    </p>
                  </div>
                )}
              </div>
            </div>

            {/* Episodes */}
            <div>
              <div className="flex items-center gap-2 mb-5">
                <Play className="w-5 h-5 text-primary" />
                <h2 className="text-xl font-bold font-display">
                  Episode <span className="text-primary">({data.totalEpisodes})</span>
                </h2>
              </div>

              <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-2">
                {data.episodes.map((ep, i) => (
                  <motion.button
                    key={ep.id}
                    initial={{ opacity: 0, scale: 0.95 }}
                    animate={{ opacity: 1, scale: 1 }}
                    transition={{ delay: Math.min(i * 0.02, 0.5) }}
                    onClick={() => navigate(ep.url)}
                    className="group flex items-center gap-2 px-3 py-2.5 rounded-lg bg-secondary border border-border text-left hover:border-primary/50 hover:bg-primary/5 transition-all"
                  >
                    <div className="w-7 h-7 rounded-md bg-primary/10 flex items-center justify-center shrink-0">
                      <Play className="w-3 h-3 text-primary" fill="currentColor" />
                    </div>
                    <span className="text-xs font-medium text-foreground/80 group-hover:text-foreground line-clamp-2 leading-tight">
                      {ep.episode}
                    </span>
                  </motion.button>
                ))}
              </div>
            </div>
          </motion.div>
        )}
      </main>
    </div>
  );
}
