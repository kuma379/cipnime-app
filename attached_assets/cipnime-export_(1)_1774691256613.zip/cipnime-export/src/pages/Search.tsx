import { useState, useEffect } from "react";
import { useLocation } from "wouter";
import { Search as SearchIcon, ChevronLeft, ChevronRight, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import AnimeCard from "@/components/AnimeCard";
import { useSearchAnime } from "@/hooks/useApi";

export default function Search() {
  const [location] = useLocation();
  const params = new URLSearchParams(window.location.search);
  const initialQuery = params.get("q") || "";

  const [query, setQuery] = useState(initialQuery);
  const [searchInput, setSearchInput] = useState(initialQuery);
  const [page, setPage] = useState(1);
  const [, navigate] = useLocation();

  const { data, isLoading, isFetching } = useSearchAnime(query, page);

  useEffect(() => {
    const p = new URLSearchParams(window.location.search);
    const q = p.get("q") || "";
    if (q !== query) {
      setQuery(q);
      setSearchInput(q);
      setPage(1);
    }
  }, [location]);

  function handleSearch(e: React.FormEvent) {
    e.preventDefault();
    if (searchInput.trim()) {
      setQuery(searchInput.trim());
      setPage(1);
      navigate(`/search?q=${encodeURIComponent(searchInput.trim())}`);
    }
  }

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      <main className="container mx-auto px-4 py-10">
        {/* Search form */}
        <div className="max-w-2xl mx-auto mb-10">
          <form onSubmit={handleSearch} className="flex gap-3">
            <div className="relative flex-1">
              <SearchIcon className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
              <input
                type="text"
                value={searchInput}
                onChange={e => setSearchInput(e.target.value)}
                placeholder="Cari anime..."
                className="w-full pl-12 pr-4 py-3 rounded-xl bg-secondary border border-border text-foreground placeholder:text-muted-foreground focus:outline-none focus:ring-2 focus:ring-primary/40 focus:border-primary"
              />
            </div>
            <button type="submit" className="px-6 py-3 bg-primary text-white rounded-xl font-semibold hover:bg-primary/90 transition-colors">
              Cari
            </button>
          </form>
        </div>

        {/* Results header */}
        {query && (
          <div className="flex items-center justify-between mb-6">
            <h2 className="text-xl font-bold font-display">
              Hasil untuk{" "}
              <span className="text-primary">&ldquo;{query}&rdquo;</span>
            </h2>
            {data && <span className="text-sm text-muted-foreground">{data.items.length} hasil</span>}
          </div>
        )}

        {/* Loading */}
        {(isLoading || isFetching) && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({ length: 12 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-[2/3] rounded-xl bg-secondary" />
                <div className="mt-2 h-3 bg-secondary rounded w-3/4" />
              </div>
            ))}
          </div>
        )}

        {/* No query */}
        {!query && !isLoading && (
          <div className="text-center py-24">
            <SearchIcon className="w-16 h-16 mx-auto text-muted-foreground/30 mb-4" />
            <p className="text-muted-foreground text-lg">Masukkan judul anime yang ingin kamu cari</p>
          </div>
        )}

        {/* No results */}
        {data && data.items.length === 0 && !isLoading && (
          <div className="text-center py-24">
            <p className="text-muted-foreground text-lg">Tidak ada hasil untuk &ldquo;{query}&rdquo;</p>
            <p className="text-muted-foreground text-sm mt-1">Coba kata kunci lain</p>
          </div>
        )}

        {/* Grid */}
        {data && data.items.length > 0 && !isLoading && (
          <motion.div
            key={`${query}-${page}`}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4"
          >
            {data.items.map((anime, i) => (
              <AnimeCard key={anime.malId} anime={anime} index={i} />
            ))}
          </motion.div>
        )}

        {/* Pagination */}
        {data && data.items.length > 0 && (
          <div className="flex items-center justify-center gap-4 mt-10">
            <button onClick={() => setPage(p => Math.max(1, p - 1))} disabled={page === 1} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary border border-border text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/10 hover:border-primary/40 transition-colors">
              <ChevronLeft className="w-4 h-4" /> Sebelumnya
            </button>
            <span className="text-sm text-muted-foreground font-medium px-4 py-2 rounded-xl bg-secondary border border-border">{page}</span>
            <button onClick={() => setPage(p => p + 1)} disabled={!data.hasNextPage} className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary border border-border text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/10 hover:border-primary/40 transition-colors">
              Berikutnya <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </main>
    </div>
  );
}
