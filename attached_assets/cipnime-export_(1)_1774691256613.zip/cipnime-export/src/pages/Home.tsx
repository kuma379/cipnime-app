import { useState } from "react";
import { ChevronLeft, ChevronRight, TrendingUp, Tv, Loader2 } from "lucide-react";
import { motion } from "framer-motion";
import Navbar from "@/components/Navbar";
import AnimeCard from "@/components/AnimeCard";
import { useLatestAnime } from "@/hooks/useApi";

export default function Home() {
  const [page, setPage] = useState(1);
  const { data, isLoading, isError } = useLatestAnime(page);

  return (
    <div className="min-h-screen bg-background">
      <Navbar />

      {/* Hero */}
      <section className="relative overflow-hidden border-b border-border bg-gradient-to-br from-primary/10 via-background to-background py-16 px-4">
        <div className="absolute inset-0 opacity-[0.03]" style={{ backgroundImage: 'radial-gradient(circle at 20% 50%, hsl(265 84% 60%) 0%, transparent 60%), radial-gradient(circle at 80% 20%, hsl(280 80% 50%) 0%, transparent 60%)' }} />
        <div className="relative container mx-auto text-center max-w-3xl">
          <motion.div initial={{ opacity: 0, y: 30 }} animate={{ opacity: 1, y: 0 }} transition={{ duration: 0.6 }}>
            <span className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/15 text-primary text-sm font-medium border border-primary/20 mb-4">
              <TrendingUp className="w-3 h-3" />
              Anime Terpopuler Minggu Ini
            </span>
            <h1 className="text-4xl md:text-6xl font-black font-display mb-4">
              Nonton Anime<br />
              <span className="text-transparent bg-clip-text bg-gradient-to-r from-primary to-purple-400">Sub Indo</span>
              {" "}Gratis
            </h1>
            <p className="text-muted-foreground text-lg max-w-xl mx-auto">
              Ribuan judul anime dengan subtitle Indonesia terlengkap. Update cepat, kualitas HD.
            </p>
          </motion.div>
        </div>
      </section>

      {/* Content */}
      <main className="container mx-auto px-4 py-10">
        <div className="flex items-center justify-between mb-6">
          <div className="flex items-center gap-2">
            <Tv className="w-5 h-5 text-primary" />
            <h2 className="text-xl font-bold font-display">Anime Populer</h2>
          </div>
          <span className="text-sm text-muted-foreground">Halaman {page}</span>
        </div>

        {isLoading && (
          <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4">
            {Array.from({ length: 24 }).map((_, i) => (
              <div key={i} className="animate-pulse">
                <div className="aspect-[2/3] rounded-xl bg-secondary" />
                <div className="mt-2 h-3 bg-secondary rounded w-3/4" />
                <div className="mt-1 h-2.5 bg-secondary rounded w-1/2" />
              </div>
            ))}
          </div>
        )}

        {isError && (
          <div className="text-center py-20">
            <AlertIcon />
            <p className="text-muted-foreground mt-2">Gagal memuat data. Coba lagi nanti.</p>
          </div>
        )}

        {data && (
          <motion.div
            key={page}
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-6 gap-4"
          >
            {data.items.map((anime, i) => (
              <AnimeCard key={anime.malId} anime={anime} index={i} />
            ))}
          </motion.div>
        )}

        {/* Pagination */}
        {data && (
          <div className="flex items-center justify-center gap-4 mt-10">
            <button
              onClick={() => setPage(p => Math.max(1, p - 1))}
              disabled={page === 1}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary border border-border text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/10 hover:border-primary/40 transition-colors"
            >
              <ChevronLeft className="w-4 h-4" /> Sebelumnya
            </button>
            <span className="text-sm text-muted-foreground font-medium px-4 py-2 rounded-xl bg-secondary border border-border">
              {page}
            </span>
            <button
              onClick={() => setPage(p => p + 1)}
              disabled={!data.hasNextPage}
              className="flex items-center gap-2 px-5 py-2.5 rounded-xl bg-secondary border border-border text-sm font-medium disabled:opacity-30 disabled:cursor-not-allowed hover:bg-primary/10 hover:border-primary/40 transition-colors"
            >
              Berikutnya <ChevronRight className="w-4 h-4" />
            </button>
          </div>
        )}
      </main>

      {/* Footer */}
      <footer className="border-t border-border py-6 px-4 text-center text-sm text-muted-foreground mt-10">
        <p>&copy; 2025 CipNime — Nonton anime sub indo gratis. For educational purposes only.</p>
      </footer>
    </div>
  );
}

function AlertIcon() {
  return (
    <div className="w-16 h-16 mx-auto rounded-full bg-destructive/10 flex items-center justify-center">
      <Loader2 className="w-8 h-8 text-destructive" />
    </div>
  );
}
