# CipNime — Anime Streaming App

Nonton anime subtitle Indonesia gratis. Menggunakan Jikan API (MyAnimeList) untuk metadata dan scraping dari Gogoanime & Kusonime untuk streaming.

## Stack

- **Frontend**: React 18 + Vite + TailwindCSS v4 + Framer Motion
- **Backend**: Express.js (Node.js)
- **Data**: Jikan API (metadata) + Gogoanime & Kusonime (streaming)
- **Deployment**: Vercel (static frontend + serverless API)

## Setup Lokal

### Prerequisites
- Node.js 18+
- npm atau pnpm

### Install & Run

```bash
# Install dependencies
npm install

# Jalankan server API lokal (port 3001)
npm run dev:api

# Di terminal lain, jalankan frontend (port 5173)
npm run dev:client

# Atau jalankan keduanya sekaligus
npm run dev
```

Buka http://localhost:5173 di browser.

## Deploy ke Vercel

### Cara 1: Via Vercel CLI
```bash
npm install -g vercel
vercel --prod
```

### Cara 2: Via GitHub + Vercel Dashboard
1. Push ke GitHub repository
2. Buka [vercel.com](https://vercel.com) → New Project
3. Import repository GitHub kamu
4. Setting build:
   - **Framework**: Vite
   - **Build Command**: `npm run build`
   - **Output Directory**: `dist`
5. Deploy!

### Cara 3: Upload Langsung
1. Build dulu: `npm run build`
2. Upload folder `dist` ke Vercel

## Upload ke GitHub

```bash
git init
git add .
git commit -m "feat: initial CipNime app"
git branch -M main
git remote add origin https://github.com/USERNAME/cipnime.git
git push -u origin main
```

## Struktur Project

```
cipnime/
├── api/
│   └── index.js       # Backend API (Express + scraper)
├── src/
│   ├── components/    # React components
│   ├── pages/         # Halaman app
│   ├── hooks/         # React hooks
│   └── lib/           # Utilities
├── public/            # Static assets
├── vercel.json        # Konfigurasi Vercel
├── vite.config.ts     # Konfigurasi Vite
└── package.json
```

## Fitur

- ✅ Browse anime populer dengan pagination
- ✅ Search anime berdasarkan judul
- ✅ Detail anime (synopsis, genre, rating, daftar episode)
- ✅ Video player dengan multiple server (Gogoanime, Kusonime, Samehadaku)
- ✅ Fallback ke link eksternal jika stream tidak tersedia
- ✅ Dark mode anime-themed UI
- ✅ Mobile responsive
- ✅ Siap deploy ke Vercel

## Catatan

- Data anime dari [Jikan API](https://jikan.moe/) (MyAnimeLabel API)
- Video stream dari Gogoanime dan Kusonime
- Untuk keperluan edukasi saja
